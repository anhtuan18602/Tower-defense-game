import scalafx.geometry.Pos
import scalafx.scene.image.Image
import scalafx.scene.layout._

import scala.collection.mutable.Buffer
//This class represent the menu where the player chooses levels
class LevelMenu extends GridPane{



  this.alignment = Pos.TopCenter

  val buttonContainer1 = new VBox

  buttonContainer1.spacing = 30
  buttonContainer1.alignment = Pos.CenterRight
  val buttonContainer2 = new VBox

  buttonContainer2.spacing = 30
  buttonContainer2.alignment = Pos.Center
  val buttonContainer3 = new VBox

  buttonContainer3.spacing = 30
  buttonContainer3.alignment = Pos.CenterLeft

  this.add(buttonContainer1,0,1,1,1)
  this.add(buttonContainer2,1,1,1,1)
  this.add(buttonContainer3,2,1,1,1)
  val cconstraint = new ColumnConstraints
  val rconstraint0 = new RowConstraints
  val rconstraint1 = new RowConstraints
  cconstraint.percentWidth = 33
  rconstraint0.percentHeight = 0
  rconstraint1.percentHeight = 100
  this.columnConstraints = Array[ColumnConstraints](cconstraint,cconstraint,cconstraint)
  this.rowConstraints =  Array[RowConstraints](rconstraint0,rconstraint1)
  //val containers = Array(buttonContainer1,buttonContainer2,buttonContainer3)
  val button1 = Buffer[GameButton]()
  val button2 = Buffer[GameButton]()
  val button3 = Buffer[GameButton]()
  val buttonList = Array(button1,button2,button3)
  for(i <- 1 to 9) {
    val levelButton = new GameButton {
      text = i.toString

      prefWidth = 360
      prefHeight = 107
      onAction = (event) => println("Start map " + i)
    }
    buttonList((i-1)%3) += levelButton
  }
  buttonContainer1.children = buttonList(0)
  buttonContainer2.children = buttonList(1)
  buttonContainer3.children = buttonList(2)
  this.background = new Background(Array(new BackgroundImage(new Image("images/mainmenubackground.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Default, new BackgroundSize(1200,800, true, true, true, true))))
  //this.children = Array(header,buttonContainer1,buttonContainer2,buttonContainer3)
}
