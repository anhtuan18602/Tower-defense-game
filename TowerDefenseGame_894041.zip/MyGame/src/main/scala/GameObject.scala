import scala.collection.mutable.Buffer
import components._
abstract class GameObject {
  //The game objects instances will add components to the empty Buffer below to be updated.
  val componentList = Buffer[Component]()

  def update(): Unit
}
