

abstract class Projectile extends GameObject {
  def update(): Unit
  var optionTarget: Option[Array[Enemy]] = None
}
