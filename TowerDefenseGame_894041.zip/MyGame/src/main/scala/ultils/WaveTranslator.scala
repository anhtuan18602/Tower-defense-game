package ultils

import scala.collection.mutable.Buffer
import scala.util.Random

object WaveTranslator {

  private val random = new Random()

  def setSeed(x: Long) = random.setSeed(x)

  def translateWaveInfo(totalHpAndTime: (Double, Int)) = {
    var totalHp = totalHpAndTime._1
    val time = totalHpAndTime._2
    val remainingWave = Buffer[(String, Double)]()
    while (totalHp != 0) {
      var enemyName = Constant.enemyNameList(random.nextInt(Constant.enemyNameList.length))
      while (Constant.enemyStats.filter(_._1 == enemyName).head._2 > totalHp) {
        enemyName = Constant.enemyNameList(random.nextInt(Constant.enemyNameList.length))
      }
      totalHp -= Constant.enemyStats.filter(_._1 == enemyName).head._2
      remainingWave += Tuple2(enemyName, random.nextInt(time))
    }
    remainingWave
  }

}
