
import javafx.scene.paint.ImagePattern
import scalafx.scene.effect.Bloom
import scalafx.scene.image.Image
import scalafx.scene.layout.{Background, BackgroundImage, BackgroundPosition, BackgroundRepeat, BackgroundSize}

import scalafx.scene.paint.Color.Transparent
import scalafx.scene.shape._
import ultils.SpriteSheet

import scala.collection.immutable.Map


package object Constant {
  val objSList = Array[String]("laser","crossbow","catapult","rock","infantry","berserker","king","warcart","berserked")
  val Cornerside = 80
  val towerSize = 80
  val barrelSize = 80

  val buttonSize = 135

  val arrowSize = (25,7)

  val laserProjSize = 25

  val rockSize = 30

  val HPwidth = 340
  val HPheight = 85


  val speedBW = 83
  val speedBH = 55

  val dirMap = Map("North" -> -90,"East" -> 0,"South" -> 90,"West" -> 180)

  // 2 speed mode
  var speedIndex = 0
  val speedModList = Array(1.0,2.0)
  def speedMod = speedModList(speedIndex)

  val enemyNameList = Array("infantry","king","warcart","berserker")
  val enemySizeList = Map("infantry" -> 40,"king" -> 75,"warcart" -> 80,"berserker"-> 60)


  val arrowImg = new Image("images/arrow.png")
  val rockImg = new Image("images/rock.png")

  //val laserProjPattern = new ImagePattern(new Image("images/lightning.png"))

  val deadPatternList = enemyNameList.map(x => (x -> new ImagePattern(new Image("images/" + x + "dead.png")))).toMap

  val roadImageHPattern = new ImagePattern(new Image("images/roadhorizontal.png"))
  val roadImageHSPattern = new ImagePattern(new Image("images/roadsquarehorizontal.png"))
  val roadImageVPattern = new ImagePattern(new Image("images/roadvertical.png"))
  val roadImageVSPattern = new ImagePattern(new Image("images/roadsquarevertical.png"))
  val roadImageCPattern = new ImagePattern(new Image("images/roadcorner.png"))

  val backgroundImagePattern = new ImagePattern(new Image("images/background.png"))

  val HPbarPattern = new ImagePattern(new Image("images/hpbarfull.png"))

  val prevList = Array(new ImagePattern(new Image("images/laserprev.png")),
                        new ImagePattern(new Image("images/catapultprev.png")),
                        new ImagePattern(new Image("images/crossbowprev.png")))
  val invalidPrevList = Array( new ImagePattern(new Image("images/laserprevinvalid.png"))
                              ,new ImagePattern(new Image("images/catapultprevinvalid.png"))
                              ,new ImagePattern(new Image("images/crossbowprevinvalid.png")))
  //                                  HP,speed
  def enemyStats = Array(Tuple4("king",50.0,0.75,Constant.kingImgPattern),
                        Tuple4("infantry",10.0,1.0,Constant.infantryImgPattern),
                        Tuple4("warcart",20.0,2.0,Constant.warcartImgPattern),
                        Tuple4("berserker",20.0,1.5,Constant.berserkerImgPattern))
  //                                damage,price,range,speed
  def towerStat = Map(("crossbow" ->(5,10,170,100,Constant.crossbowBaseImgPattern)),
                      ("catapult" ->(7,20,250,200,Constant.catapultBaseImgPattern)),
                      ("laser"->(15,40,200,150,Constant.lightningBaseImgPattern)))

  SpriteSheet.loadSpriteSheet("images/crossbowbarrel.png","crossbow",32,32)
  SpriteSheet.loadSpriteSheet("images/catapultbarrel.png","catapult",32,32)
  SpriteSheet.loadSpriteSheet("images/laserbarrel.png","laser",32,32)
  SpriteSheet.loadSpriteSheet("images/infantry.png","infantry",32,32)
  SpriteSheet.loadSpriteSheet("images/warcart.png","warcart",32,32)
  SpriteSheet.loadSpriteSheet("images/king.png","king",32,32)
  SpriteSheet.loadSpriteSheet("images/infantryattacked.png","infantryAttacked",32,32)
  SpriteSheet.loadSpriteSheet("images/laserprojectile.png","laserline",32,32)
  SpriteSheet.loadSpriteSheet("images/berserker.png","berserker",32,32)
  SpriteSheet.loadSpriteSheet("images/berserked.png","berserked",32,32)
  SpriteSheet.loadSpriteSheet("images/hpbar.png","HP",128,32)

  val speed0 = new Background(Array(new BackgroundImage(new Image("images/speedbutton0.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(speedBW,speedBH, true, true, true, false))))
  val speed1 = new Background(Array(new BackgroundImage(new Image("images/speedbutton1.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(speedBW,speedBH, true, true, true, false))))
  val speedB = Array(speed0,speed1)
  val speed0Hover = new Background(Array(new BackgroundImage(new Image("images/speedbutton0hover.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(speedBW,speedBH, true, true, true, false))))
  val speed1Hover = new Background(Array(new BackgroundImage(new Image("images/speedbutton1hover.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(speedBW,speedBH, true, true, true, false))))
  val speedBHover = Array(speed0Hover,speed1Hover)
  val lightningButton =new BackgroundImage(new Image("images/laserbutton.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))
  val catapultButton = new BackgroundImage(new Image("images/catapultbutton.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))
  val crossBowButton = new BackgroundImage(new Image("images/crossbowbutton.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))
  val removeButton = new Background(Array(new BackgroundImage(new Image("images/removebutton.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))))
  val replayButton = new Background(Array(new BackgroundImage(new Image("images/replaybutton.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))))
  val removeButtonHover = new Background(Array(new BackgroundImage(new Image("images/removebuttonhover.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))))
  val replayButtonHover = new Background(Array(new BackgroundImage(new Image("images/replaybuttonhover.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))))

  val menuBackground = new Background(Array(new BackgroundImage(new Image("images/menu.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Center, new BackgroundSize(buttonSize,buttonSize, true, true, true, false))))

  val buttonList = Array(new Background(Array(lightningButton)),new Background(Array(catapultButton)),new Background(Array(crossBowButton)))

  //Initial image for the towers
  val crossbowBaseImgPattern = new ImagePattern(new Image("images/crossbowbase.png"))
  val crossbowBarrelImgPattern = new ImagePattern(new Image("images/crossbowbarrel0.png"))

  val catapultBaseImgPattern = new ImagePattern(new Image("images/catapultbase.png"))
  val catapultBarrelImgPattern = new ImagePattern(new Image("images/catapult0.png"))

  val lightningBaseImgPattern = new ImagePattern(new Image("images/laserbase.png"))
  val lightningBarrelImgPattern = new ImagePattern(new Image("images/laserbarrel0.png"))


  //Initial image for the enemies
  val kingImgPattern = new ImagePattern(new Image("images/king0.png"))
  val infantryImgPattern = new ImagePattern(new Image("images/infantry0.png"))
  val warcartImgPattern =new ImagePattern(new Image("images/warcart0.png"))
  val berserkerImgPattern =new ImagePattern(new Image("images/berserker0.png"))
  // image pattern for enemy indication
  val indicationPattern = new ImagePattern(new Image("images/indication.png"))

  def arrowRectangle = {
    val rec = new Rectangle {
      width = 1
      height = 1
    }
    rec.setFill(new ImagePattern(arrowImg))
    rec
  }
  def rockRectangle = {
    val rec = new Rectangle {
      width = rockSize
      height = rockSize
    }
    rec.setFill(Transparent)
    rec
  }

  def laserLine = {
    val line = new Line {
    }
    line.setStroke(SpriteSheet.imageDataBase("laserline")(0))
    line.setStrokeWidth(10)
    line.setSmooth(true)
    line.opacity = 0.9
    val bloom = new Bloom()
    bloom.setThreshold(0.5)
    line.setEffect(bloom)
    line
  }


}
