package ultils

import javafx.scene.paint.ImagePattern
import scalafx.embed.swing.SwingFXUtils
import scalafx.scene.image.Image

import java.awt.image.BufferedImage
import scala.collection.mutable.Buffer
import scala.collection.mutable.Map

object SpriteSheet {
  //the sprite database of the whole game
  val imageDataBase = Map[String, Array[ImagePattern]]()

  //method for loading sprite into imageDataBase
  def loadSpriteSheet(path: String,name:String, spriteWidth: Double, spriteHeight: Double) = {

        val sheet = new Image(path)
        val sheetWidth = sheet.getWidth()
        val sheetHeight = sheet.getHeight()

        val xEnd = (sheetWidth - spriteWidth).toInt
        val yEnd = (sheetHeight - spriteHeight).toInt

        val bufferedSheet = SwingFXUtils.fromFXImage(sheet, null)
        //println(bufferedSheet.getSubimage(0,0,spriteWidth.toInt,spriteHeight.toInt))
        sheet.getHeight().toInt

        val images = Buffer[ImagePattern]()
        for {
            //y <- 0 to  yEnd by spriteHeight.toInt
            x <- 0 to xEnd by spriteWidth.toInt
        }{

            val subImageCut = bufferedSheet.getSubimage(x,0,spriteWidth.toInt, spriteHeight.toInt)
            val subImage = new BufferedImage(subImageCut.getWidth(),subImageCut.getHeight(),subImageCut.getType)
            val g = subImage.getGraphics
            g.drawImage(subImageCut,0,0,null)
            g.dispose()

            //println(sprite.height)
            val pattern = new ImagePattern(SwingFXUtils.toFXImage(subImage, null)) // We save images in form that is easiest to use.

            images += pattern
        }

        imageDataBase += (name -> images.toArray)
        println("Loaded " + images.size + " sprites from " + path)
    }

}
