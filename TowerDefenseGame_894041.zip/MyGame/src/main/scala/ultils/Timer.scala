package ultils

object Timer {
  // The time object used for gameloop, this will keep track of the game progress for wave spawning and tower attack speed
  private var timeStamp = 0.0
  private var paused = false
  private var previousTime = 0.0
  def previous = previousTime
  def isPaused = paused
  def pause = paused = true
  def resume = paused = false
  def update() = {
    if(!paused) {

       timeStamp += 1//*Constant.speedMod
    }
  }
  // reset method is called when the gameloop restart or when one wave is over.
  def reset() = {
    previousTime += timeStamp
    timeStamp = 0.0
  }
  def time = timeStamp
}
