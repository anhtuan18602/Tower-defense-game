import scalafx.scene.layout.VBox
 import scalafx.geometry.Pos
import scalafx.scene.control.Label

import scalafx.scene.paint.Color._
import scalafx.scene.text.{Font, FontPosture, FontWeight}
// This class represent the pause menu in game or when game is over
class ReplayMenu extends VBox{
  val vbox = new VBox
  this.prefWidth = 340
  this.prefHeight = 400
  this.spacing = 10
  this.alignment = Pos.Center
  this.background = Constant.menuBackground
  val header = new Label("Replay")
  //header.padding = Insets(50, 25, 10, 25)
  header.font = Font.font("Pixel Rand",FontWeight.Light,FontPosture.Regular,40)
  header.setTextFill(Orange)
  header.alignment = Pos.TopCenter
  val buttonContainer = new VBox
  //buttonContainer.padding = Insets(100, 200, 100, 200)
  buttonContainer.spacing = 10
  buttonContainer.alignment = Pos.TopCenter
  val continueButton = new GameButton {
    text = "Continue"
    prefWidth = 184
    prefHeight = 48
  }
  val restartButton = new GameButton {
    text = "Restart"

    prefWidth = 184
    prefHeight = 48
    onAction = (event) => println("Start game")
  }
  val menuButton = new GameButton {
    text = "Menu"
    prefWidth = 184
    prefHeight = 48
  }
  buttonContainer.children = Array(continueButton,restartButton,menuButton)

  this.children = Array(header,buttonContainer)


}
