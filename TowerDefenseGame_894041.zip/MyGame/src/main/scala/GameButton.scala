import scalafx.scene.control.Button
import scalafx.scene.image.Image
import scalafx.scene.layout._
import scalafx.scene.paint.Color._
import scalafx.scene.text.{Font, FontPosture, FontWeight}
class GameButton extends Button{
  this.background =
        new Background(
            Array(
                new BackgroundImage(
                    new Image("images/gameButton.png"),
                    BackgroundRepeat.NoRepeat,
                    BackgroundRepeat.NoRepeat,
                    BackgroundPosition.Center,
                    new BackgroundSize(160, 48, true, true, true, true)
                )
            )
        )
        this.textFill = Orange

         onMouseEntered = (event) =>{ this.background =
        new Background(
            Array(
                new BackgroundImage(
                    new Image("images/gamebuttonhover.png"),
                    BackgroundRepeat.NoRepeat,
                    BackgroundRepeat.NoRepeat,
                    BackgroundPosition.Center,
                    new BackgroundSize(160, 48, true, true, true, true)
                )
            )
        )
        textFill = Red
         }
        onMouseExited  = (event) => { this.background =
        new Background(
            Array(
                new BackgroundImage(
                    new Image("images/gameButton.png"),
                    BackgroundRepeat.NoRepeat,
                    BackgroundRepeat.NoRepeat,
                    BackgroundPosition.Center,
                    new BackgroundSize(160, 48, true, true, true, true)
                )
            )
        )
          textFill = Orange
       }
        this.font  = Font.font("Pixel Rand",FontWeight.Light,FontPosture.Regular,25)
}
