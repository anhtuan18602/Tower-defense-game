import components.{LocationComponent, RecRenderComponent}
import scalafx.scene.shape.Rectangle

import scala.collection.mutable.Buffer

class Corner(location: (Double,Double),a: Double,b: Double,s: Double) extends  GameObject {
     val lc = new LocationComponent(location)
    //road construction
     val image = new Rectangle {
       if(a >= 0 && b >=0) {
        width = a + s
        height = b + s
        x=lc.x
        y=lc.y
       }

       else {
         width = -a + s
       height = -b + s
        x=lc.x + a
        y=lc.y + b

       }

     }

    //each corners have a dir variable for enemy to use to find moving direction and also for smooth road image.
     var dir = ""



      if(a ==0) {
        image.setFill(Constant.roadImageVPattern)
        if(b >0) dir = "South" else dir ="North"

      }
      else {
        image.setFill(Constant.roadImageHPattern)
        if(a >0) dir = "East" else dir ="West"
      }




     val rc = new RecRenderComponent(image,lc)
     componentList ++= Buffer(lc,rc)
     def update(): Unit = {}

     def loc = location
     def side = a

  }
