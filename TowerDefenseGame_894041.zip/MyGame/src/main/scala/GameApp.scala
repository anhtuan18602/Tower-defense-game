import scalafx.application.JFXApp
import scalafx.scene.text.Font

object GameApp extends JFXApp {
  Font.loadFont(getClass.getClassLoader.getResourceAsStream("font/PixelRand.otf"), 100)
  val gui = new GameGui()

  stage = new JFXApp.PrimaryStage {
    title.value = "Tower defense"
    width = 1200
    height = 800
    scene = gui
  }

}
