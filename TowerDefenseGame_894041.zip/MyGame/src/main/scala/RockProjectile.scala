import components.{AudioComponent, LinearMovementComponent, LocationComponent, RecRenderComponent, ResizeMovementComponent, RotateMovementComponent}
import javafx.scene.paint.ImagePattern

import java.lang.Math.{abs, pow, sqrt}
import scalafx.scene.paint.Color._

class RockProjectile(tower: Tower) extends Projectile {

  /*The class RockProjectile represent the rocks from the catapults.
    The rocks will fly towards the enemies and grow bigger in the first half and grow smaller in the second half of the journey to create the effect of curved flying.
    When hit, the rock will breaks and affect enemies close by, making them lose HP and stunned for a short while (berserker is not affected by stun).
  */


  val lc = new LocationComponent(tower.lc.x+ (Constant.towerSize-Constant.rockSize)/2.0,tower.lc.y+ (Constant.towerSize-Constant.rockSize)/2.0)
  val rc = new RecRenderComponent(Constant.rockRectangle,lc)
  val mc = new LinearMovementComponent(0,0,lc)
  val rmc = new RotateMovementComponent(0,rc,lc)
  val rsmc = new ResizeMovementComponent(1,1,rc)
  val ac = new AudioComponent("rock")
  def speed = 7.0 * Constant.speedMod
  componentList ++= Array(lc,rc,mc,rmc,rsmc,ac)

  def update() = {
    if(optionTarget.isDefined) {

      val target = optionTarget.get.head
      rc.rec.setFill(new ImagePattern(Constant.rockImg))
      //rc.getImage.fill = Black
      val distance = sqrt(pow(abs(target.lc.x-this.lc.x),2) + pow(abs(target.lc.y-this.lc.y),2))
      if(distance >= 5.0*Constant.speedMod) {
        //speed -= 0.04
        val changeX = (target.lc.x-this.lc.x) * speed/distance
        val changeY = (target.lc.y-this.lc.y) * speed/distance
        mc.dx = changeX
        mc.dy = changeY
        if(distance >= tower.dis(tower.lc,target.lc)/2.0) {
          rsmc.modifierX = 4.0/3.0
          rsmc.modifierY = 4.0/3.0
        }
        else {
          rsmc.modifierX = 0.8
          rsmc.modifierY = 0.8
        }
        //rmc.angle += 15
        //rc.getImage.width = Constant.rockSize
        //rc.getImage.height = Constant.rockSize
        componentList.foreach(_.update())
      }
      else {
        //speed = 7
        lc.x = tower.lc.x+ (Constant.towerSize-Constant.rockSize)/2.0
        lc.y = tower.lc.y+ (Constant.towerSize-Constant.rockSize)/2.0
        rc.getImage.width = Constant.rockSize
        rc.getImage.height = Constant.rockSize
        //rmc.angle = tower.barrelMove.angle
        ac.play = true
        componentList.foreach(_.update())
        rc.rec.setFill(Transparent)
        optionTarget.get.foreach(_.attacked(tower.name,tower.damage))
        optionTarget.get.foreach(Effect.addAffected(tower.name,"attack",39,_))
        optionTarget = None

      }
    }
  }
}
