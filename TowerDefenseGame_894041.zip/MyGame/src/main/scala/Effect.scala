
import javafx.scene.paint.ImagePattern
import ultils.{SpriteSheet, Timer}

import scalafx.scene.image.Image

import scala.collection.mutable.Buffer
/*This object keeps track of different effects in the game, both visually and logically.
attack: this will affect the enemy image when attacked by different towers (showing arrows, electrocuted, or fall when hit by rocks)
dead: this will show the dying enemy fading away and also play the sound of enemy grunt
berserk: this is a special effect of enemy of type berserker, which will happen when he reaches below half HP, he becomes faster.

The effects will be created with a time at that moment called and a t variable representing the amount of time the effect is in place,
when t has passed, or currentTime - t = initial, the effect is removed
with dead effect t over meaning the enemy is dead and removed from the game altogether.
*/
object Effect extends GameObject {
  def create() = {this}
  //                         start, amount, name, enemy,tower
  var affectedList = Buffer[(Double,Double,String,Enemy,String)]()
  def addAffected(causer:String,name:String,t:Double,enemy: Enemy) = {
    val currentStamp =Timer.time
    affectedList += Tuple5(currentStamp,t,name,enemy,causer)
  }
  def update() = {
    val newList = affectedList.clone()
    //println(affectedList.length)
    for(affected <- affectedList) {
      if(affected._1 + affected._2 == Timer.time) {

        newList -= affected
        affected._3 match {
          case "attack" =>{
            affected._4.speed = affected._4.stat._3
            affected._4.sprite.upd = true
            affected._4.sprite.imageList = SpriteSheet.imageDataBase(affected._4.name)
          }
          case "dead" => {
            affected._4.setDead(true)

          }
          case "berserk" => {}
        }
      }
      else {
        affected._3 match {
          case "attack" => {
            affected._5 match {
              case "crossbow" => {
                if(!affected._4.berserked) {
                  affected._4.sprite.upd = false
                  affected._4.rc.rec.setFill(new ImagePattern(new Image("images/"+ affected._4.name +  "attackedby"+affected._5+".png")))
                }
              }
              case "catapult" => {
                if(affected._4.name != "berserker") {
                  affected._4.sprite.upd = false
                  affected._4.rc.rec.setFill(new ImagePattern(new Image("images/"+ affected._4.name +  "attackedby"+affected._5+".png")))
                  affected._4.speed = 0.0
                }
              }
              case "laser" => affected._4.rc.rec.setFill(new ImagePattern(new Image("images/attackedbylaser.png")))
            }
          }
          case "dead" =>  {

            affected._4.sprite.upd = false
            if(affected._5 != "laser") {
              affected._4.rc.rec.setFill(Constant.deadPatternList(affected._4.name))
            }
            else affected._4.rc.rec.setFill(new ImagePattern(new Image("images/deadbylaser.png")))
            var currentTime = Timer.time
            if(affected._1 > Timer.time) currentTime += Timer.previous
            affected._4.rc.rec.opacity = 1.0*((affected._1+affected._2-currentTime)/affected._2)
            //println(1.0*((affected._1+affected._2-currentTime)/affected._2))

          }
          case "berserk" => {
            if(Timer.time == affected._1+1.0) {
              affected._4.ac.name = "berserked"
              affected._4.ac.play = true
            }
            else affected._4.ac.name = affected._4.name
            affected._4.speed = 2.5
            affected._4.sprite.imageList = SpriteSheet.imageDataBase("berserked")
            affected._4.sprite.delay = 7

          }
        }
      }
    }
    affectedList = newList
  }
}
