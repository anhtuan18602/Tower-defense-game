import components._


import Math.{abs, pow, sqrt}
class ArrowProjectile(tower: Tower) extends Projectile {
  //one tower has only one projectile instance
  val lc = new LocationComponent(tower.lc.x+12.5,tower.lc.y+12.5)
  val rc = new RecRenderComponent(Constant.arrowRectangle,lc)
  val mc = new LinearMovementComponent(0,0,lc)
  val rmc = new RotateMovementComponent(0,rc,lc)
  def speed = 8*Constant.speedMod
  componentList ++= Array(lc,rc,mc,rmc)


  def update() = {
    if(optionTarget.isDefined) {
      val target = optionTarget.get.head

      val distance = sqrt(pow(abs(target.lc.x-this.lc.x),2) + pow(abs(target.lc.y-this.lc.y),2))
      // The arrow will fly until it is close enough to the enemy
      if(distance >= 5.0*Constant.speedMod) {
        val changeX = (target.lc.x-this.lc.x) * speed/distance
        val changeY = (target.lc.y-this.lc.y) * speed/distance
        mc.dx = changeX
        mc.dy = changeY
        rmc.angle = tower.barrelMove.angle
        rc.getImage.width = Constant.arrowSize._1
        rc.getImage.height = Constant.arrowSize._2
        componentList.foreach(_.update())
      }
        //when close enough
      else {
        //the arrow location is reset back to the tower location and resize to make it invisible
        lc.x = tower.lc.x+Constant.towerSize/2.0
        lc.y = tower.lc.y+Constant.towerSize/2.0
        rc.getImage.width = 1
        rc.getImage.height = 1
        rmc.angle = tower.barrelMove.angle
        componentList.foreach(_.update())
        // attack effect and method is called to apply damage
        Effect.addAffected(tower.name,"attack",15,target)
        target.attacked(tower.name,tower.damage)
        // target is reset to None until a new target is given
        optionTarget = None

      }
    }
      //no target available, the arrow is also moved back to the tower and is resized to be invisble
    else {
      lc.x = tower.lc.x+Constant.towerSize/2.0
        lc.y = tower.lc.y+Constant.towerSize/2.0
        rc.getImage.width = 1
        rc.getImage.height = 1
        componentList.foreach(_.update())

    }
  }
}
