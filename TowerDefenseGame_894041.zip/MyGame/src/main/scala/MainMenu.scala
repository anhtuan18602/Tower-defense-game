import scalafx.geometry.Pos
import scalafx.scene.control.Label
import scalafx.scene.image.Image
import scalafx.scene.layout._
import scalafx.scene.paint.Color._
import scalafx.scene.text.{Font, FontPosture, FontWeight}
// This class represents the main menu
class MainMenu extends VBox{
  val vbox = new VBox

  this.spacing = 10
  this.alignment = Pos.Center
  val header = new Label("Knight & Laser")
  //header.padding = Insets(50, 25, 10, 25)
  header.font = Font.font("Pixel Rand",FontWeight.Light,FontPosture.Regular,120)
  header.setTextFill(Orange)
  val buttonContainer = new VBox
  //buttonContainer.padding = Insets(100, 200, 100, 200)
  buttonContainer.spacing = 10
  buttonContainer.alignment = Pos.TopCenter
  val playButton = new GameButton {
    text = "Play"

    prefWidth = 360
    prefHeight = 107
    onAction = (event) => println("Start game")
  }
  buttonContainer.children = Array(playButton)
  this.background = new Background(Array(new BackgroundImage(new Image("images/mainmenubackground.png"),BackgroundRepeat.NoRepeat, BackgroundRepeat.NoRepeat, BackgroundPosition.Default, new BackgroundSize(1200,800, true, true, true, true))))
  this.children = Array(header,buttonContainer)
}

