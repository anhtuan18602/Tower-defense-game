import components._
import scalafx.scene.shape.{Circle, Rectangle}
import scalafx.scene.paint.Color._
import ultils.{SpriteSheet, Timer}

import scala.collection.mutable.Buffer
import scala.math.{abs, pow, sqrt}
class Tower(location:(Double,Double),game:Game,val name:String) extends GameObject {
  // The tower get its stats from a map in Constant
  val stat = Constant.towerStat(name)
  // variable startTime represents the last time the tower has attacked
  var startTime = Timer.time - attackSpeed
  val sprite = SpriteSheet.imageDataBase(name)
  val damage = stat._1
  val price = stat._2
  val range = stat._3
  def attackSpeed = stat._4 / Constant.speedMod
  // The tower consists of the barrel and the base
  val baseImage =  new Rectangle {
      height = Constant.towerSize
      width = Constant.towerSize
    }
  var waveCount = game.waveCount

  baseImage.setFill(stat._5)
  baseImage.x = location._1
  baseImage.y =location._2
  val barrelImage = new Rectangle {
    width = Constant.barrelSize
    height = Constant.barrelSize
  }

  barrelImage.setFill(sprite(0))
  barrelImage.x = location._1
  barrelImage.y =location._2

  val lc = new LocationComponent(location)
  baseImage.x = lc.x
  baseImage.y = lc.y

  val rc = new RecRenderComponent(baseImage,lc)
  val barrelLc = new LocationComponent(location._1-(Constant.barrelSize-Constant.towerSize)/2.0,location._2-(Constant.barrelSize-Constant.towerSize)/2.0)
  val barrelRc = new RecRenderComponent(barrelImage,barrelLc)
  val barrelMove = new RotateMovementComponent(0,barrelRc,barrelLc)
  val barrelSprite = new SpriteComponent(sprite,barrelRc,5)
  val ac = new AudioComponent(this.name)
  var showRange = false


  // This range circle is used to display the range of the tower, display when tower is clicked
  val rangeCircle = new Circle {
      centerX = lc.x + rc.rec.height.value/2
      centerY = lc.y + rc.rec.height.value/2
      radius = range
      fill = Blue
      opacity = 0
    }


  barrelImage.onMouseClicked = (event) => {
    if(!showRange) {
      rangeCircle.opacity = 0.3
      rangeCircle.centerX = lc.x + rc.rec.height.value/2
      rangeCircle.centerY = lc.y + rc.rec.height.value/2
      showRange = true
    }
    else {
      rangeCircle.opacity = 0
      rangeCircle.centerY = -100
      rangeCircle.centerX = -100
      showRange = false
    }
  }
  val rangeRc = new CircleRenderComponent(rangeCircle,lc)

  name match {
    case "laser" => {

      barrelSprite.delay = 10
      barrelSprite.upd = true
      barrelSprite.continuous = true
    }
    case "catapult" => {
      barrelSprite.delay = 5
    }
    case _ =>
  }
  val projectile = {
    name match {
      case "crossbow" => new ArrowProjectile(this)
      case "catapult" => new RockProjectile(this)
      case "laser" => new LaserProjectile(this)
    }

  }
  componentList ++= Buffer(lc,rangeRc,rc,barrelLc,barrelRc,barrelMove,barrelSprite,ac)
  game.addObject(projectile)
  def update() = {
    if(!Timer.isPaused) {
      // If a new wave has just been spawned, the last attack time "startTime" will be reset to 0
      if(game.waveCount != waveCount) {
        startTime = 0.0
        waveCount = game.waveCount
      }
      if(inRange().nonEmpty ) {

        val enemies = this.inRange()
        val distance = sqrt(pow((enemies.head.lc.x - this.lc.x),2) + pow((enemies.head.lc.y - this.lc.y),2))

        barrelMove.angle = if(enemies.head.lc.y >= this.lc.y) Math.acos((enemies.head.lc.x - this.lc.x)/(distance))*180/Math.PI else 360 -
          Math.acos((enemies.head.lc.x - this.lc.x)/(distance))*180/Math.PI


        if(abs(Timer.time-startTime)>attackSpeed) {

          startTime = Timer.time
          attack(enemies)
          ac.play = true
        }
      }
      componentList.foreach(_.update())
    }
  }
  def inRange() : Buffer[Enemy] = {
    val enemies = game.remainingEnemies
    enemies.filter(a => (pow(abs(a.lc.x-this.lc.x),2) + pow(abs(a.lc.y-this.lc.y),2)) <= pow(range,2)).filter(_.isAlive).filter(!_.dying).
    sortBy(a => (pow(abs(a.lc.x-this.lc.x),2) + pow(abs(a.lc.y-this.lc.y),2)))

  }
  def dis(a:LocationComponent,b:LocationComponent) = sqrt( pow(a.x -b.x,2) + pow(a.y -b.y,2))
  def attack(enemies:Buffer[Enemy]) = {

    this.name match {
      case "crossbow" => {
        barrelSprite.upd = true
        projectile.optionTarget = Some(Array(enemies.head))

      }
      case "catapult" => {
        barrelSprite.upd = true
        projectile.optionTarget = Some((enemies.filter(x => dis(x.lc,enemies.head.lc) < 100)).toArray)

      }
      case "laser" => {
          projectile.optionTarget = Some(enemies.take(3).toArray)



        for(i <- enemies.take(3).indices) {
          Effect.addAffected(this.name,"attack",15,enemies(i))
          enemies(i).attacked(name,damage)
        }
      }
    }
  }
}
