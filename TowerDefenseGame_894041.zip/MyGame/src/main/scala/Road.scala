import components._
import scalafx.scene.shape.Rectangle

class Road(locations: Array[(Double,Double)], side: Double) {


  //this class keep info of the corners of a road in the game.
   var corners= Array[Corner]()
  //this method check if a specific location is part of the road or not
   def isRoad(location: (Double,Double)) = {
     corners.exists(a => a.image.contains(location._1,location._2))
   }

     for(i <- locations.indices) {
       if(i != locations.length -1) {

          val loc = locations(i)
          val next = locations(i+1)
          corners = corners :+ new Corner(loc,next._1-loc._1,next._2-loc._2,side)

       }
       else {
         val corner = new Corner(locations(i),side,side,0)
         if(corners.last.dir == "South" || corners.last.dir == "North") corner.image.setFill(Constant.roadImageVSPattern) else corner.image.setFill(Constant.roadImageHSPattern)
         corners = corners :+  corner
       }

     }
     for( i<- 1 until corners.length-1) {
      val cornerImg = new Rectangle {
       width = Constant.Cornerside
       height = Constant.Cornerside
       x = corners(i).lc.x
       y = corners(i).lc.y
      }
       //the corner image is the square at the corner of the road, the if's else's below is for rotating this square to make a smooth looking road.
      cornerImg.setFill(Constant.roadImageCPattern)

      if(corners(i-1).dir == "East") {
        if(corners(i).dir == "North") cornerImg.rotate = 180
      else cornerImg.rotate = 90
      }
     else if(corners(i-1).dir == "West") {
       if(corners(i).dir == "North") cornerImg.rotate = -90
       else cornerImg.rotate = 0
     }
     else if(corners(i-1).dir == "North") {
       if(corners(i).dir == "East") cornerImg.rotate = 0
       else cornerImg.rotate = 90
     }
     else if(corners(i-1).dir == "South") {
       if(corners(i).dir == "East") cornerImg.rotate = -90
       else cornerImg.rotate = 180
     }
     corners(i).componentList += new RecRenderComponent(cornerImg,corners(i).lc)
    }
   def list = corners

}