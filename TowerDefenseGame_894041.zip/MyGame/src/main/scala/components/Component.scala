package components
trait Component {
  def update(): Unit
}
