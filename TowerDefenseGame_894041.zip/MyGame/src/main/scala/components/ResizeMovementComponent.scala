package components

import ultils.Timer
//This class changes size of the images in game.
class ResizeMovementComponent(var modifierX:Double,var modifierY: Double,rc:RecRenderComponent) extends MovementComponent {
  def update() = {
    if(modifierX != -1.0) {
      if(Timer.time%8 ==0) {
        if(rc.getImage.width.value <= 100 ||rc.getImage.height.value <= 100) {
          rc.getImage.width = rc.getImage.width.value*modifierX
          rc.getImage.height =  rc.getImage.height.value*modifierY
        }
      }
    }
    else {
      rc.getImage.width = 10
      rc.getImage.height = 10
      modifierX = 1.0
      modifierY = 1.0
    }
  }
}
