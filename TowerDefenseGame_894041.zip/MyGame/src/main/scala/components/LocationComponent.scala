package components
//This class represent the location of all game objects
class LocationComponent(loc:(Double,Double)) extends Component {
  var x = loc._1
  var y = loc._2
  def update() = {}
}
