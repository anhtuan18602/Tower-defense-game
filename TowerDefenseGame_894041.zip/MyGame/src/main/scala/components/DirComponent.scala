package components
//This class represent the 4 directions rotation of enemies
class DirComponent(var currentFacing: String, rMC:RotateMovementComponent) extends Component {
  val directions = Array("North","East","South","West")

  var newDir : Option[String] = None
  def update() = {
    if(newDir.isDefined) {

      rMC.angle = Constant.dirMap(newDir.get)
      newDir = None
    }
  }
}
