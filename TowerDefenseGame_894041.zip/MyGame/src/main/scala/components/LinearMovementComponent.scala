package components
//This class represent the movement of the enemy
class LinearMovementComponent(var dx: Double, var dy: Double, lc: LocationComponent) extends MovementComponent {
  def update() = {
    lc.x += dx
    lc.y += dy
  }
}
