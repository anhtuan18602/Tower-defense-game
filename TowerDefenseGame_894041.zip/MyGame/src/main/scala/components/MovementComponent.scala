package components

abstract class MovementComponent extends Component {
  update(): Unit
}
