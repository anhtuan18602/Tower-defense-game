package components
import scalafx.scene.Node
abstract class RenderComponent extends Component {
  def getImage:Node
  def update()
}
