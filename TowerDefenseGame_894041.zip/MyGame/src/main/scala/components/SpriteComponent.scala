package components
import javafx.scene.paint.ImagePattern
import scalafx.embed.swing.SwingFXUtils
import scalafx.scene.image.Image
import ultils.Timer
import javafx.scene.paint.Color._

//This class represent the sprites of the objects in game who needs change of image states.
class SpriteComponent(var imageList: Array[ImagePattern], rc:RenderComponent,var delay: Int) extends Component {
  var upd = false
  var continuous = false
  var i = 1

  def update() = {
    if(upd) {
        if(Timer.time%(delay/Constant.speedMod) ==0)   {

          rc match {
            case rec:RecRenderComponent => {
              rec.rec.setFill(imageList(i))

            }
            case line:LineRenderComponent => line.getImage.setStroke(imageList(i))
          }
          if(i == imageList.length-1) {
            i = 0

            if(!continuous) {

              upd = false
            }
          }
          else i +=1
        }
    }
  }
}

