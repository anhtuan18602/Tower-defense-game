package components
//This class rotates the images in game
class RotateMovementComponent(var angle:Double, rc: RecRenderComponent, lc: LocationComponent) extends MovementComponent {

  def update() = {
    rc.getImage.x = lc.x + rc.rec.width.value/2.0
    rc.getImage.y = lc.y + rc.rec.width.value/2.0
    rc.getImage.rotate = angle

    rc.getImage.x = lc.x
    rc.getImage.y = lc.y

  }
}
