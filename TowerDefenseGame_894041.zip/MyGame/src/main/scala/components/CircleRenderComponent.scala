package components
import scalafx.scene.shape.Circle
class CircleRenderComponent(circle: Circle,lc:LocationComponent) extends RenderComponent {
  def update() = {}
  def getImage = circle
}
