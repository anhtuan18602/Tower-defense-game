package components

import scalafx.scene.shape.Rectangle

//This class represents the image of the game objects of type Rectangle
class RecRenderComponent(var rec: Rectangle, lc: LocationComponent) extends RenderComponent {

  def update() = {
    rec.x = lc.x
    rec.y = lc.y
  }
  def getImage = rec
}
