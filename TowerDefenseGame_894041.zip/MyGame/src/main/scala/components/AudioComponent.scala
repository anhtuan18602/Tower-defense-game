package components
//This class represent the audio in game
class AudioComponent(var name:String) extends Component {
  //when play is set to true, the game will get the audio file name and play it
  var play = false
  def getAudioStr = name
  def update() = {
  }
}
