package components
import scalafx.scene.shape._
//This class renders the lines of the LaserProjectile
class LineRenderComponent(line:Line, lc1:LocationComponent,lc2:LocationComponent) extends RenderComponent {
  def update() = {
    line.startX = lc1.x
    line.startY = lc1.y
    line.endX = lc2.x
    line.endY = lc2.y
  }
  def getImage = line
}
