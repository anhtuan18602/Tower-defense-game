import ultils.{Timer, WaveTranslator}

import scala.collection.mutable.Buffer
import scalafx.scene.Node
import components._
import scalafx.scene.shape.Rectangle

import scala.util.Random
class Game(url:String) {
  //read the map json file given to create game
    val jsonString = os.read(os.pwd/"src"/"main"/"scala"/"maps"/url)
    val data = ujson.read(jsonString)
  val gameObjects = Buffer[GameObject]()
  //the buffer "roads"  each cornerlist instances represent a road
  val roads = Buffer[Road]()
  var state = "Replay"
  //the buffer "waveRoads" is the list of waves. Each Array of wave represent the waves coming from each roads.
  val waveRoads = Buffer[Array[Wave]]()
  for( i<- 0 until data("Number of roads").num.toInt) {
  val corners = new Road((data("Corner Location X "+ i.toString).arr.map(_.num).zip(data("Corner Location Y "+ i.toString).arr.map(_.num))).toArray,Constant.Cornerside)
    for(corner <- corners.list) {
      gameObjects += corner
    }
    roads += corners
    val waveInfoList = data("Wave HPs "+ i.toString).arr.map(_.num).zip(data("Wave time "+ i.toString).arr.map(_.num.toInt))

    var waveList = Array[Wave]()
    /*
      In the json file, the Wave HPs give the total HP of the enemies in each waves. The Wave time represent the latest time an enemy can be spawned in each wave
      The wave translator translates each wave total HP and total spawn time into a real wave info with enemy name and spawn time.
     */
    for(waveInfo <- waveInfoList) {
      waveList = waveList :+ new Wave(WaveTranslator.translateWaveInfo(waveInfo),data("Initial facing "+ i.toString).str,corners,this)
    }
    waveRoads += waveList
  }

  val player = new Player(200.0,data("Initial money").num.toInt)
  val seed:Long = data("Seed").num.toLong
  val random = new Random(seed)
  var waveDelay = 150
  // when isDelay, the game shows indication of where enemies will come from in the next wave
  var isDelay = true
  val towerList = Buffer[Tower]()
  val effect = Effect.create()
  gameObjects += player
  gameObjects += effect
  var waveCount = 0

  WaveTranslator.setSeed(seed)
  var remainingEnemies = Buffer[Enemy]()


  def changeSpeed() = {
    Constant.speedIndex = (Constant.speedIndex +1)%2
  }


  private var victory = false
  private var lost = false
  def isWon = victory
  def isLost = lost
  def addTower(location: Option[(Double,Double)],name:String) = {
    if(location.isDefined && !towerList.exists(a => a.lc.x == location.get._1 && a.lc.y == location.get._2)
      && !roads.exists(corners => corners.isRoad(location.get)) && location.get._2>=80 && location.get._2 <= 560 && player.getMoney >= Constant.towerStat(name)._2) {
      val newTower = new Tower(location.get,this,name)


      towerList += newTower
      gameObjects += newTower
      player.addMoney(-newTower.price)
      true
    }
    else false
  }
  def removeTower(location: Option[(Double,Double)]) = {
    if(location.isDefined && towerList.exists(a => a.lc.x == location.get._1 && a.lc.y == location.get._2)) {
      val tower = towerList.filter( a => a.lc.x == location.get._1 && a.lc.y == location.get._2).head
      player.addMoney(tower.price/2)
      towerList -= tower
      gameObjects -= tower
    }
  }


 //Use the first corners from each roads to draw an indication of incoming enemy.
  val firstCorners = waveRoads.map(x => x.head.corners.list.head)
  val indications = Buffer[Rectangle]()
  for(corner <- firstCorners) {
    val indicationRec = new Rectangle {
      x = corner.lc.x
      y = corner.lc.y
      width = Constant.Cornerside
      height = Constant.Cornerside
      rotate = Constant.dirMap(corner.dir)
    }
    indicationRec.setFill(Constant.indicationPattern)
    indications += indicationRec
  }
  //This variable zip each road with its indication
  val zipped = waveRoads.zip(indications)

  def addObject(gameObject: GameObject) = gameObjects += gameObject
  def update() = {
    if(!Timer.isPaused) {
      for(obj <- gameObjects) {
        obj.update()
      }
      if(player.isDestroyed) {
        state = "Defeat"
        lost = true
        Timer.reset()
      }
      else {
      if(isDelay || (waveCount < waveRoads.head.length &&  waveRoads.forall(waveList => waveList(waveCount).remainingWave.isEmpty) && remainingEnemies.isEmpty)) {
        if(waveDelay ==0) {
          isDelay = false
          waveDelay = 150
          waveCount += 1
          Timer.reset()
        }
        else {
          isDelay = true
          waveDelay -=1
        }
      }
      val remains = remainingEnemies.clone()
      remainingEnemies.foreach(i => if(!i.isAlive || i.isPassed) {
       if(i.name == "warcart" && !i.isPassed) {
         val infantry = new Enemy("infantry",i.initialFacing,i.corners, this)
         i.replace(infantry)
         remains += infantry
         gameObjects += infantry
       }
       remains -= i
       gameObjects -= i
      }

     )
     remainingEnemies = remains.clone()
     if(waveCount < waveRoads.head.length && !isDelay) {
       for(waveList <- waveRoads) {
        val someEnemy = waveList(waveCount).update()

        if(someEnemy.isDefined) {

          gameObjects +=  someEnemy.get
          remainingEnemies += someEnemy.get
        }
       }
     }

     else {

        if(remains.isEmpty && !isDelay) {
          state = "victory"
          victory = true
          Timer.reset()
        }
      }
    }

    Timer.update()
  }
  }
  //this method returns the node for showing in games and the audio file name to be played
  def imageAndAudio = {
        val objects = Buffer[GameObject]()
        objects ++= gameObjects diff gameObjects.collect{case a: Projectile => a}
        objects ++= gameObjects.collect{case a: Projectile => a}

        val img = Buffer[Node]()
        val audio = Buffer[String]()
        val componentList = objects.flatMap(go => go.componentList)
        componentList.foreach(c => {
            c match {
                case renderC: RenderComponent => img += renderC.getImage
                case ac: AudioComponent => {
                  if(ac.play) audio += ac.getAudioStr
                  ac.play = false
                }
                case _ =>
            }
        })
      if(waveCount +1 < waveRoads.head.length && this.isDelay && waveDelay%50 <=25) {
        img ++= zipped.filter(x => !x._1(waveCount +1).isEmpty).map(x => x._2)
      }

    (img,audio)

    }

}
