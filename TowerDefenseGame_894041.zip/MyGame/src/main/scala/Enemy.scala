import components._
import ultils._

import scalafx.scene.shape.Rectangle

import scala.collection.mutable.Buffer
import scala.math._
import scala.util.Random

class Enemy(val name: String, val initialFacing: String, val corners:Road, game: Game  ) extends GameObject {
  private val random = new Random()



  val stat = Constant.enemyStats.filter(_._1 == name).head
  var lc = new LocationComponent(corners.list.head.loc._1,corners.list.head.loc._2+ random.nextInt(Constant.Cornerside-(Constant.enemySizeList(name)/2.0).toInt) + random.nextDouble())
  var healthPoint = stat._2
  var speed = stat._3
  var image = stat._4
  var track = 1

  val initialHP = healthPoint

  private var dead = false

  val mc = new LinearMovementComponent(0,0,lc)
  val rec = new Rectangle {
    width = Constant.enemySizeList(name)
    height = Constant.enemySizeList(name)
  }
  rec.setFill(stat._4)
  val rc = new RecRenderComponent(rec,lc)
  val sprite = new SpriteComponent(SpriteSheet.imageDataBase(name),rc,10)
  sprite.continuous = true
  sprite.upd = true

  val rMC = new RotateMovementComponent(Constant.dirMap(initialFacing),rc,lc)
  val dc = new DirComponent(findDirection,rMC)
  val ac = new AudioComponent(this.name)
  componentList ++= Buffer(lc,mc,rc,sprite,dc,rMC,ac)
  def setLocation(a:Double,b:Double) = {
    lc.x = a
    lc.y = b
  }
  def setDead(boolean: Boolean) = dead = boolean
  def currentHealthPoint = healthPoint
  def currentSpeed = speed* Constant.speedMod
  def nextCorner = corners.list(track)
  def location = lc
  //method findDirection finds the next direction after reaching a corner square
  def findDirection:String = {
    val dX = nextCorner.loc._1 - corners.list(track -1).lc.x
    val dY = nextCorner.loc._2 - corners.list(track -1).lc.y
       if(abs(dX) > abs(dY)) {
          if(dX >0) "East"
          else  "West"
       }
       else {
          if(dY >0) "South"
          else  "North"
       }
    }
  var dying = false
  def isAlive: Boolean = !dead
  private var passed: Boolean = false
  var direction = initialFacing

  var berserked = false
  var latestTowerName = ""
  def attacked(towerName:String,amount: Double) = {
    healthPoint -= amount
    //if the enemy is berserker and his HP is below half, make it go berserk.
    if(this.name == "berserker" && healthPoint <= stat._2/2.0 && healthPoint >0 && !berserked) {
      Effect.addAffected(towerName,"berserk",0,this)
      berserked = true

    }
    latestTowerName = towerName

  }
  var destination = setDestination

  //this method returns a random position in the next corner square for the enemy
  def setDestination = {
    direction match {
      case "East"|"West" => (nextCorner.loc._1 + random.nextInt(Constant.Cornerside-(Constant.enemySizeList(name)/2.0).toInt),lc.y)
      case "North"|"South" => (lc.x,nextCorner.loc._2 + random.nextInt(Constant.Cornerside-(Constant.enemySizeList(name)/2.0).toInt))
    }

  }
  //this method is used for warcart. When a war cart die, the infantry is spawned where it died.
  def replace(infantry: Enemy) = {
    infantry.setLocation(this.lc.x,this.lc.y)
    infantry.track = this.track
    infantry.dc.newDir = Some(infantry.findDirection)
    infantry.direction = infantry.findDirection
    infantry.destination = this.destination
  }
  def isPassed = passed

  //this method checks if the enemy has reached the next corner square
  def reached = abs(this.lc.x - destination._1)< currentSpeed && abs(this.lc.y - destination._2)< currentSpeed
  def update(): Unit = {
      if(this.healthPoint <= 0 && this.isAlive && !dying) {
        dying = true
        ac.play = true
        Effect.addAffected(latestTowerName,"dead",50,this)
        game.player.addMoney(this.initialHP/4)
      }

      if(this.isAlive && !passed && !dying) {

        val nextPos = getdxdy
        this.mc.dx = nextPos._1
        this.mc.dy = nextPos._2

        componentList.foreach(_.update())
        if(reached) {
          if(track ==  corners.list.length-1) {
            passed = true
            game.player.pass(this.initialHP)
          }
          else {
            track += 1
            direction = findDirection
            destination = setDestination
            dc.newDir = Some(findDirection)
          }
        }
      }


  }
  // this method returns the change in position
  def getdxdy : (Double,Double) = {
    direction match {
      case "East" => (currentSpeed,0)
      case "West" => (-currentSpeed,0)
      case "North" => (0,-currentSpeed)
      case "South" => (0,currentSpeed)
    }
  }
}
