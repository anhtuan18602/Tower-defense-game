import ultils.Timer
import scala.collection.mutable.Buffer
//This class instance represent a wave of enemies
class Wave(nameAndSpawn: Buffer[(String,Double)], initialFacing:String, val corners: Road, game: Game) {
  def isEmpty = nameAndSpawn.isEmpty
  var remainingWave = nameAndSpawn.clone()
  def update():Option[Enemy] = {

    var spawned: Option[Enemy] = None
    for(nAS <- nameAndSpawn) {
      //when it's time (when game timestamp equals the time given to the enemy), the enemy will be created and returned to be added to Game's gameobjects list
      if(nAS._2 == Timer.time) {

        spawned = Some(new Enemy(nAS._1,initialFacing,corners,game) )
        remainingWave -= nAS
      }
    }
    spawned
  }
}
