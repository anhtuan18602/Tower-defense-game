import javafx.scene.paint.ImagePattern
import scalafx.animation.AnimationTimer
import scalafx.scene.control.{Button, Label}
import scalafx.scene.image.Image
import scalafx.scene.input.MouseButton
import scalafx.scene.media.AudioClip
import scalafx.scene.paint.Color.{Blue, Green, Orange, Red, Transparent}
import scalafx.scene.shape.{Circle, Rectangle}
import scalafx.scene.text.{Font, FontPosture, FontWeight}
import scalafx.scene.{Group, Node, Scene}
import ultils.Timer

import scala.collection.mutable.Buffer
import scala.util.Random

class GameGui() extends Scene {
  var gameOption :Option[Game] = None
  var isInGame = false
  var currentMap = ""
  var pause = false
  val buttonSound = new AudioClip(getClass.getResource("audio/button.wav").toExternalForm)
  val mainMenu = new MainMenu {
    buttonSound.play()
    playButton.onAction = (event) => toLevelMenu()
  }
  val levelMenu = new LevelMenu {
    buttonList.foreach(x => x.foreach(b => b.onAction = (event) => {
      buttonSound.play()
      currentMap = "map" + b.text.value + ".json"
      toGame("map" + b.text.value + ".json")
    }))

  }
  val gameView = new Group

   var buttonPlacementWidth = 1180
  val towerTypeList = Array("laser","catapult","crossbow")
  var setTower = false
  var removeTower = false
  val towerButtonList = Buffer[Button]()
  var i = 0
  val allButton = Buffer[Button]()


  for(tower <- towerTypeList) {
    val towerButton = new Button(tower)
    buttonPlacementWidth = buttonPlacementWidth - Constant.buttonSize -10
    towerButton.setLayoutX(buttonPlacementWidth)
    towerButton.setLayoutY(615)
    towerButton.textFill = Transparent

    towerButton.setBackground(Constant.buttonList(i))
    towerButton.minWidth = Constant.buttonSize
    towerButton.minHeight = Constant.buttonSize
    towerButtonList += towerButton
    allButton += towerButton
    i+=1
  }
  var towerIndex = 0
  var towerName = ""
  for(button <- towerButtonList) {
      button.onMouseClicked =(event) => {
          Timer.pause
          removeTower = false
          setTower = true
          towerIndex = towerButtonList.indexOf(button)
          towerName = button.text.value
      }

    }
  val removeButton = new Button {
    layoutX = 757
    layoutY = 15
    text = "remove"
    textFill = Transparent
    minWidth = Constant.speedBW
    minHeight = Constant.speedBH
    background = Constant.removeButton
    onAction = (event) => {
      buttonSound.play()
      if(!removeTower) {
        Timer.pause
        removeTower = true
        setTower = false
      }
      else {
        Timer.resume
        removeTower = false
      }
    }
    onMouseEntered = (event) => {
      background = Constant.removeButtonHover
    }
    onMouseExited = (event) => {
      background = Constant.removeButton
    }
  }
  allButton += removeButton
  val replayButton = new Button {
    layoutX = 1098
    layoutY = 15
    prefWidth = Constant.speedBW
    prefHeight = Constant.speedBH
    text = "replay"
    textFill = Transparent
    background = Constant.replayButton
    onAction = (event) => {
      buttonSound.play()
      pause = true
      Timer.pause
    }
    onMouseEntered = (event) => {
      background = Constant.replayButtonHover
    }
    onMouseExited = (event) => {
      background = Constant.replayButton
    }
  }
  allButton += replayButton
  val replayMenu = new ReplayMenu {
    layoutX = 430
    layoutY = 200
    continueButton.onAction = (event) => {
      buttonSound.play()
      Timer.resume
      pause = false
    }
    restartButton.onAction = (event) =>{
      buttonSound.play()
      mainTheme.stop()
      mainTheme = new AudioClip(getClass.getResource("audio/MainTheme"+ Random.nextInt(3).toString + ".wav").toExternalForm)
      mainTheme.play()
      pause = false
      Timer.reset()
      Timer.resume
      toGame(currentMap)

    }
    menuButton.onAction = (event) => {
      buttonSound.play()
      pause = false
      Timer.reset()
      Timer.resume
      toLevelMenu()
    }
  }



  val money = new Label()
  val changeMoney = new Label()
  val labelList = Array(money,changeMoney)
  for(mon <- labelList) {
    mon.prefWidth  = 200
    mon.prefHeight = 100
    Font.loadFont(getClass.getClassLoader.getResourceAsStream("font/PixelRand.otf"),100)
    mon.font = Font.font("Pixel Rand",FontWeight.Light,FontPosture.Regular,100)
  }
  //money.text = game.player.getMoney.toInt.toString
  money.layoutX = 960
  money.layoutY = -45
  money.setTextFill(Orange)
  //changeMoney.text = game.player.getChange
  changeMoney.layoutX = 960
  changeMoney.layoutY = 30

  val coin = new Rectangle {
    width = 38
    height = 38
    x = 920
    y = 23
  }
  coin.setFill(new ImagePattern(new Image("images/coin.png")))
  val speedButton = new Button("speed")

  speedButton.setLayoutX(827)
  speedButton.setLayoutY(15)
  speedButton.textFill = Transparent
  speedButton.setBackground(Constant.speedB(0))
  speedButton.minWidth = Constant.speedBW
  speedButton.minHeight = Constant.speedBH
  allButton += speedButton
  speedButton.onMouseClicked = (event) => {
    if(gameOption.isDefined) {
      gameOption.get.changeSpeed()
      speedButton.setBackground(Constant.speedB(Constant.speedIndex))
    }
  }
  speedButton.onMouseEntered = (event) => speedButton.setBackground(Constant.speedBHover(Constant.speedIndex))
  speedButton.onMouseExited = (event) => speedButton.setBackground(Constant.speedB(Constant.speedIndex))
  for(button <- towerButtonList) {
    button.onMouseEntered   = (event) => {
        button.prefWidth = Constant.buttonSize*1.05
        button.prefHeight = Constant.buttonSize*1.05
      }
    button.onMouseExited = (event) => {
        button.prefWidth = Constant.buttonSize
        button.prefHeight =  Constant.buttonSize
    }

  }


  val previewRec = new Rectangle{
    width = Constant.towerSize
    height = Constant.towerSize
  }
  val previewRange = new Circle{
    fill = Blue
    opacity = 0.3
  }
  val background = new Rectangle {
    width = 1190
    height = 760
    x = 0
    y = 0
  }
  background.setFill(Constant.backgroundImagePattern)

  this.onMouseMoved = event => {
    if(gameOption.isDefined) {

      if(setTower) {
        val a = (event.getSceneX)-(event.getSceneX)%Constant.towerSize
        val b = (event.getSceneY)-(event.getSceneY)%Constant.towerSize
        if(gameOption.get.roads.exists(corners =>corners.isRoad((a,b)))) {previewRec.setFill(Constant.invalidPrevList(towerIndex))}
        else if(b <80 || b >560) {
          previewRec.fill = Transparent
          previewRange.fill = Transparent
        }
        else {
          previewRec.setFill(Constant.prevList(towerIndex))
          previewRange.fill = Blue
        }
        previewRec.opacity = 1
        previewRec.x = a
        previewRec.y = b
        previewRange.centerX = a + Constant.towerSize/2
        previewRange.centerY = b + Constant.towerSize/2
        previewRange.radius = Constant.towerStat(towerName)._3
      }
      else if(removeTower) {
        val a = (event.getSceneX)-(event.getSceneX)%Constant.towerSize
        val b = (event.getSceneY)-(event.getSceneY)%Constant.towerSize
        if(b <80 || b >= 560) {previewRec.fill = Transparent}
        else previewRec.fill = Red
        previewRec.opacity = 0.5
        previewRec.x = a
        previewRec.y = b
      }
    }

  }

  val builtsound = new AudioClip(getClass.getResource("audio/builtsound.wav").toExternalForm)
  builtsound.volume = 10
  this.onMouseClicked = event => {
    if(event.getButton == MouseButton.Primary.delegate  && gameOption.isDefined) {
      if(setTower) {
        val a = (event.getSceneX)-(event.getSceneX)%Constant.towerSize
        val b = (event.getSceneY)-(event.getSceneY)%Constant.towerSize

        if(gameOption.get.addTower(Some(a,b),towerName)) { builtsound.play()}

      }
      else if(removeTower) {
        val a = (event.getSceneX)-(event.getSceneX)%Constant.towerSize
        val b = (event.getSceneY)-(event.getSceneY)%Constant.towerSize
        gameOption.get.removeTower(Some(a,b))
      }
    }
    else {
      if(setTower) {
        Timer.resume
        setTower = false
      }
      if(removeTower) {
        Timer.resume
        removeTower = false
      }
    }
  }
  var mainTheme = new AudioClip(getClass.getResource("audio/MainTheme"+ Random.nextInt(3).toString + ".wav").toExternalForm)
  mainTheme.volume = 10
  mainTheme.cycleCount = 100
  mainTheme.play()
  val audios = Constant.objSList.map(x => x -> new AudioClip(getClass.getResource("audio/" + x + "sound.wav").toExternalForm)).toMap
  audios.values.foreach(_.volume = 10)

  val mainLoop = AnimationTimer((nsnow) => {
   if(gameOption.isDefined) {
     val game = gameOption.get
    game.update()


    val imgAud = game.imageAndAudio
      for( audioName <- imgAud._2) {

        audios(audioName).play()
      }
      // Add event to show tower's range

      //update Labels

      money.text = game.player.getMoney.toInt.toString
      val change = game.player.moneyChange
      changeMoney.text = game.player.getChange
      if(change.toInt != 0) {
        changeMoney.setTextFill(if(change.toInt >0) Green else Red)
      }
      else changeMoney.setTextFill(Transparent)


      //update Images
      val cont = Buffer[Node](background)


      //cont += game.rangeCircle
      cont ++= imgAud._1

      cont += coin
      cont += money
      cont += changeMoney

      if(setTower || removeTower) {
        cont += previewRec
        if(!removeTower) {
          cont += previewRange
        }
      }


      for(button <- allButton) {
        cont += button
      }
    if(game.isLost || game.isWon || pause) {
        Timer.pause
        replayMenu.header.text = game.state
        cont += replayMenu
      }
    gameView.children = cont
   }
  })

  this.root = mainMenu

  def toGame(url:String) :Unit = {

    gameOption = Some(new Game(url))
    isInGame = true
    mainLoop.start()
    this.root = gameView
  }
  def toLevelMenu():Unit = {
    gameOption = None
    isInGame = false
    mainLoop.stop()
    this.root = levelMenu
  }
  def toMainMenu(): Unit = {
    isInGame = false
    mainLoop.stop()
    this.root = mainMenu
  }
}
