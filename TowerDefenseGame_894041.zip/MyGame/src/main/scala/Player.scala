
import components._

import scalafx.scene.shape.Rectangle
import ultils.SpriteSheet
class Player(HP: Double, money: Double) extends GameObject {
  private var destroyed = false
  private var currentHealthPoint = HP
  private var currentMoney = money
  private var initialHP = HP
  var t = 20
  // The image representation of the player is the HP hearts bar
  val lc = new LocationComponent((0,0))
  val rec = new Rectangle {
    width = Constant.HPwidth
    height = Constant.HPheight
    x = 0
    y = 0
  }
  rec.setFill(Constant.HPbarPattern)
  val rc = new RecRenderComponent(rec,lc)

  var moneyChange = 0.0
  componentList ++= Array(lc,rc)
  def getMoney = currentMoney
  def getHP = currentHealthPoint
  def isDestroyed = destroyed
  def pass(amount: Double) = {
    currentHealthPoint -= amount
    /*The image of the HP bar changes to less hearts everytime a tenth of the total health is lost.
      eg: total health is 200, the number of hearts is 5
      when 20 HP is lost, the number of hearts becomes 4.5
    */
    rec.setFill(SpriteSheet.imageDataBase("HP")(((initialHP-currentHealthPoint)/initialHP*10.0).toInt))
    rec.width = Constant.HPwidth *1.02
    rec.height = Constant.HPheight *1.02

  }
  def addMoney(amount: Double) = {
    t = 20
    currentMoney += amount
    moneyChange = amount
  }
  def getChange = {
    val re = moneyChange.toInt.toString
    t -= 1
    if(t ==0) {
      moneyChange = 0.0
      t= 20
    }
    " "*(3-re.length) + re
  }
  def update() = {
    rec.width = Constant.HPwidth
    rec.height = Constant.HPheight
    if(this.currentHealthPoint <= 0.0) {
      destroyed = true
    }
  }
}
