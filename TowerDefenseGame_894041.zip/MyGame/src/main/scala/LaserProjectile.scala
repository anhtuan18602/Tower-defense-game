import components.{ LineRenderComponent, LocationComponent}
import ultils.Timer



class LaserProjectile(tower: Tower) extends Projectile {
  val lc = new LocationComponent(tower.lc.x+Constant.towerSize/2.0,tower.lc.y+Constant.towerSize/2.0)
  var lightningLcList = Array[(LocationComponent,LocationComponent)]()
  /*construct lines equal the maximum number of enemy that Laser tower can attack
   Each are accompanied by LineRenderComponent and two locationComponent
  */

  var rcList = Array[LineRenderComponent]()
  for(i <- 0 until 4) {
    val lc1 = new LocationComponent(tower.lc.x+Constant.towerSize/2.0,tower.lc.y+Constant.towerSize/2.0)
    val lc2 = new LocationComponent(tower.lc.x+Constant.towerSize/2.0,tower.lc.y+Constant.towerSize/2.0)
    val rc = new LineRenderComponent(Constant.laserLine,lc1,lc2)


    componentList ++= Array(lc1,lc2,rc)
    lightningLcList = lightningLcList :+ (lc1,lc2)
    rcList =rcList :+ rc
  }

  def update() = {
    //When targets are defined, the location of the lines will be the positions of the enemies.
    if(optionTarget.isDefined) {
      val target = optionTarget.get
      lightningLcList(0)._2.x = target.head.lc.x + target.head.rc.getImage.width.value/2.0
      lightningLcList(0)._2.y = target.head.lc.y + target.head.rc.getImage.width.value/2.0
      rcList.foreach(_.getImage.opacity = 0.9)
      for(i <- 1 until target.length) {

        lightningLcList(i)._1.x = target(i-1).lc.x + target(i-1).rc.getImage.width.value/2.0
        lightningLcList(i)._1.y = target(i-1).lc.y + target(i-1).rc.getImage.width.value/2.0
        lightningLcList(i)._2.x = target(i).lc.x + target(i).rc.getImage.width.value/2.0
        lightningLcList(i)._2.y = target(i).lc.y + target(i).rc.getImage.width.value/2.0
      }
      componentList.foreach(_.update())
      optionTarget = None
      //println(track)
    }
      // else, the lines will be invisible
    else {
      if(Timer.time%13 == 0) {
        rcList.foreach(_.getImage.opacity = 0.0)
        for(lcPair <- lightningLcList) {
          lcPair._1.x = tower.lc.x+Constant.towerSize/2.0
          lcPair._1.y = tower.lc.y+Constant.towerSize/2.0
          lcPair._2.x = tower.lc.x+Constant.towerSize/2.0
          lcPair._2.y = tower.lc.y+Constant.towerSize/2.0
          componentList.foreach(_.update())
        }
      }
    }
    }
}
